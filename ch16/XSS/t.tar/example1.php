<HTML><BODY>
<PRE>
You put in the data:
<?php print($_REQUEST["name"] . "\n")?>
<?php print($_REQUEST["address"] . "\n")?>
<?php print($_REQUEST["country"] . "\n")?>
</PRE>
</BODY>
</HTML>
