<?php
  $site = "PentesterLab &rarrow;";
  require "header.php";
  User::logout();
  header("Location: /index.php");
  die();
?>


