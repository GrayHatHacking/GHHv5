<?php

    $lnk = mysql_connect("localhost", "pentesterlab", "pentesterlab");
    $db = mysql_select_db('cbc', $lnk);

?>
