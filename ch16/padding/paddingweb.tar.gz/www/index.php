<?php
  $site = "PentesterLab &rarrow; Padding Oracle";
  require "header.php";
?>

<div class="row">
  <div class="col-lg-12">
    <h1>Padding Oracle</h1>
      <p>Welcome to the <a href="https://pentesterlab.com/">PentesterLab</a>'s exercise on Padding Oracle.</p>
      <p>The objective of this exercise is to find a way to get logged in as the user "admin"..</p>
  <?php if (isset($user)) { ?>
      <?php  if ($user === 'admin' ) { ?>
      <span class="text text-success">
      <?php } else { ?> 
      <span class="text text-warning">
      <?php } ?>
        You are currently logged in as <?php echo h($user); ?>!
      </span>
  <?php } else { ?>
      <p>To start, you will need to create a user (<a href="/register.php">register</a>) and then <a href="/login.php">log in</a> to exploit this vulnerability.</p>
  <?php } ?>

  </div>
</div>



<?php


  require "footer.php";
?>

